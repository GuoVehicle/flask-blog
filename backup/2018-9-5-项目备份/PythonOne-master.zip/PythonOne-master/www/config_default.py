# -*- coding: utf-8 -*-

'''
Default configurations.
'''

__author__ = 'Vehicle Guo'

configs = {
    'debug': True,
    'db': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': '664991558',
        'db': 'awesome'
    },
    'session': {
        'secret': 'Awesome'
    }
}