#-*- coding:utf8-*-
import asyncio
import www.orm
from www.models import User, Blog, Comment
import time


async def test(loop):
    #连接池异步连接
    await www.orm.create_pool(loop,user='root', password='664991558', db='awesome')
    #u = User(name='jinxn', email='test@123.com', passwd='123', image='about:blank')
    summary = 'python框架搭建 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
    u=Blog(user_id='12',user_name='guo',user_image='ss',name='Python New Study', content='123456767',summary=summary, created_at=time.time() - 3600)
    #异步保存
    await u.save()

async def find(loop):
    await www.orm.create_pool(loop,user='root', password='664991558', db='awesome')
    rs = await Blog.findAll()
    print('查找测试： %s' % rs)

# 获取EventLoop:
loop = asyncio.get_event_loop()
# 执行coroutine
loop.run_until_complete(asyncio.wait([test(loop),find(loop)]))
loop.run_forever()