# -*- coding: utf-8 -*-

'''
Override configurations.
'''

__author__ = 'Vehicle Guo'

configs = {
    'db': {
        'host': '127.0.0.1'
    }
}